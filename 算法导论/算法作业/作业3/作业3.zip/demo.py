lst=[1,2,3]
lst.insert(0,4)
print(lst)