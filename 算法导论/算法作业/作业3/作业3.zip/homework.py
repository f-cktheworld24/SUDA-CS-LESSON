t=int(input())#测试用例的数量t
n,q=map(int,input().split(" "))#数组长度n和要测试整数的总数q
lst=list(map(int,input().split(" ")))#被测试数组的内容
lst_q=[int(input()) for i in range(q)]#输入进行测试的整数,存放于列表lst_q
t_count=0#现有测试用例数量
q_count=0#现有测试整数的总数
def quicksort(lst):
    mid=int(max(lst)+min(lst))
    for i in lst:
        if i>mid:
            
while t_count<t and q_count<q:
    mid=int(max(l))
    t_count+=1
    q_count+=1




