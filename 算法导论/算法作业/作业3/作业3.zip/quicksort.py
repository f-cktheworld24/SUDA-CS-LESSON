"""lst=[37,104,99,173,130,15,37,135,72,97]
for i in range(1,len(lst)):
    for j in range(i):
        if lst[i]<lst[j]:
            lst[j],lst[i]=lst[i],lst[j]
    print("第{:2d}轮".format(j+1),lst)
print(lst)"""

# def searchInsert(nums, target):
#     if target in nums:
#         return nums.index(target)
#     else:
#         temp=1
#         for i in range(len(nums)-1):
#             if (nums[i]<=target and nums[i+1]>=target) or (nums[i]>=target and nums[i+1]<=target):
#                 temp=i+1
                
#             elif target>=nums[-1] and len(nums)!=1:
#                 temp=len(nums)
#             elif target<=nums[0] and len(nums)!=1:
#                 temp=0
#         if target<=nums[0]:
#             temp=0
#         print(temp)
#         return temp
# if __name__ == "__main__":
#     searchInsert([1,3,5,6],7)

# import random
# def quicksort(a,start,end):
#     ranind=random.randint(start,end)
#     a[start],a[ranind]=a[ranind],a[start]
#     pivot=start
#     j=start+1
#     for i in range(start+1,end+1):
#         if a[i]<=a[pivot]:
#             a[i],a[j]=a[j],a[i]
#             j+=1
#     a[pivot],a[j-1]=a[j-1],a[pivot]
#     pivot=j-1
#     return pivot


# def Quicksort(a,start,end):
#     if start>=end:
#         return 
#     pivot=quicksort(a,start,end)
#     Quicksort(a,start,pivot-1)
#     Quicksort(a,pivot+1,end)
# if __name__=="__main__":
#     a=[8,5,12,6,4,3,7,9,2,1,10,11]
#     Quicksort(a,0,11)
#     print(a)

import random
def quicksort(a,start,end,q_test):
    mid=(max(a)+min(a))//2
    a.insert(0,mid)
    #a[start],mid=mid,a[start]
    pivot=start
    j=start+1
    for i in range(start+1,end+1):
        if a[i]<=a[pivot]:
            a[i],a[j]=a[j],a[i]
            j+=1
    a[pivot],a[j-1]=a[j-1],a[pivot]
    pivot=j-1
    lst2=a[:pivot-1]
    lst3=a[pivot+1:]
    print(a)
    if sum(lst2)==q_test or sum(lst3)==q_test:
        return "Yes"
    elif q_test<min(lst2):
        a=lst3
        return pivot
    elif q_test<min(lst3):
        a=lst2
        return pivot
    else:
        return "False"


def Quicksort(a,start,end,q_test):
    if start>=end:
        return 
    pivot=quicksort(a,start,end,q_test)
    if pivot=="Yes":
        return "Yes"
    elif pivot=="False":
        return "False"
    Quicksort(a,start,pivot-1,q_test)
    Quicksort(a,pivot+1,end,q_test)
if __name__=="__main__":
    a=[1,2,3,4,5]
    print(Quicksort(a,0,len(a),1))